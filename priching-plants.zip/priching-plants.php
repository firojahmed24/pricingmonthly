<?php

if(!defined('ABSPATH')) exit;

class PricingPlants extends \Elementor\Widget_Base{

	public function get_name(){
		return "PricingPlants";
	}
	
	public function get_title(){
		return "Pricing Plants";
	}
	
	public function get_icon(){
		return "eicon-price-table";
	}

	public function get_categories(){
		return ['dreamit-category'];
	}

	protected function register_controls() {


		$this->start_controls_section(
			'button_section',
			[
				'label' => __( 'Currenr Menu', 'dreamit-elementor-extension' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$this->add_control(
			'menu_current',
            [
                'label' => __( 'Current Menu Title', 'dreamit-elementor-extension' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'label_block' => true,
                'default' => 'Monthly',
            ],
		);
		$this->add_control(
			'menu_current1',
            [
                'label' => __( 'Current Menu Title', 'dreamit-elementor-extension' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'label_block' => true,
                'default' => 'Yearly',
            ],
		);
		$this->end_controls_section();

		$this->start_controls_section(
			'package_section',
			[
				'label' => __( 'Package Item 1', 'dreamit-elementor-extension' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
			$this->add_control(
				'site_title',
				[
					'label' => esc_html__( 'Site Title', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'default' => esc_html__( 'Default title', 'dreamit-elementor-extension' ),
					'placeholder' => esc_html__( 'Most Popular', 'dreamit-elementor-extension' ),
					'label_block' => true,
				]
			);
			$this->add_control(
				'name',
				[
					'label' => __( 'Name', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'default' => __( 'Basic', 'dreamit-elementor-extension' ),
					'placeholder' => __( 'Enter Title', 'dreamit-elementor-extension' ),
				]
			);
			$this->add_control(
				'title',
				[
					'label' => esc_html__( 'Title', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'default' => esc_html__( 'Default title', 'dreamit-elementor-extension' ),
					'placeholder' => esc_html__( 'Type your title here', 'dreamit-elementor-extension' ),
					'label_block' => true,
				]
			);
			$this->add_control(
				'sub_title',
				[
					'label' => esc_html__( 'Sub Title', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'default' => esc_html__( 'Default title', 'dreamit-elementor-extension' ),
					'placeholder' => esc_html__( 'Type your title here', 'dreamit-elementor-extension' ),
					'label_block' => true,
				]
			);
			$this->add_control(
				'description',
				[
					'label' => esc_html__( 'Description', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::TEXTAREA,
					'rows' => 5,
					'default' => esc_html__( 'Default description', 'dreamit-elementor-extension' ),
					'placeholder' => esc_html__( 'Type your description here', 'dreamit-elementor-extension' ),
				]
			);
			$this->add_control(
				'currency',
				[
					'label' => __( 'Currency', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'default' => __( '$', 'dreamit-elementor-extension' ),
					'placeholder' => __( '$', 'dreamit-elementor-extension' ),
				]
			);
			$this->add_control(
				'price',
				[
					'label' => __( 'Price', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'default' => __( '99', 'dreamit-elementor-extension' ),
					'placeholder' => __( '99', 'dreamit-elementor-extension' ),
				]
			);
			$this->add_control(
				'month',
				[
					'label' => __( 'Month', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'default' => __( 'Month', 'dreamit-elementor-extension' ),
					'placeholder' => __( 'Month', 'dreamit-elementor-extension' ),
				]
			);
        // 	yearly
            
            $this->add_control(
				'currency_yearly',
				[
					'label' => __( 'Yearly Currency', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'default' => __( '$', 'dreamit-elementor-extension' ),
					'placeholder' => __( '$', 'dreamit-elementor-extension' ),
				]
			);
			$this->add_control(
				'price_yearly',
				[
					'label' => __( 'Yearly Price', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'default' => __( '99', 'dreamit-elementor-extension' ),
					'placeholder' => __( '99', 'dreamit-elementor-extension' ),
				]
			);
			$this->add_control(
				'month_yearly',
				[
					'label' => __( 'Yearly Month', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'default' => __( 'Month', 'dreamit-elementor-extension' ),
					'placeholder' => __( 'Month', 'dreamit-elementor-extension' ),
				]
			);
			$repeater = new \Elementor\Repeater();
			
			$repeater->add_control(
				'icons_type',
				[
				    'label' => esc_html__('Icon Type','dreamit-elementor-extension'),
				    'type' => \Elementor\Controls_Manager::CHOOSE,
				    'options' =>[
					  'img' =>[
						'title' =>esc_html__('Image','dreamit-elementor-extension'),
						'icon' =>'eicon-image',
					  ],
					  'icon' =>[
						'title' =>esc_html__('Icon','dreamit-elementor-extension'),
						'icon' =>'fa fa-info',
					  ]
				    ],
				    'default' => 'icon',
				]
			 );
			 $repeater->add_control(
				'list_icon',
				[
					'label' => esc_html__( 'Icon', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::ICONS,
					'condition'=>[
						'icons_type'=> 'icon',
					],
					'label_block' => true,
				]
			);
			$repeater->add_control(
				'list_img',
				[
				    'label' => esc_html__('Image','dreamit-elementor-extension'),
				    'type'=> \Elementor\Controls_Manager::MEDIA,
				    'default' => [
					  'url' => \Elementor\Utils::get_placeholder_image_src(),
				    ],
				    'condition' => [
					  'icons_type' => 'img',
				    ]
				]
			);
			$repeater->add_control(
				'list_title', [
					'label' => esc_html__( 'Title', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'default' => esc_html__( 'List Title' , 'dreamit-elementor-extension' ),
					'label_block' => true,
				]
			);

			$this->add_control(
				'feature_list',
				[
					'label' => esc_html__( 'Feature List', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::REPEATER,
					'fields' => $repeater->get_controls(),
					'default' => [
						[
							'list_title' => esc_html__( 'Special Feature #1', 'dreamit-elementor-extension' ),
						],
						[
							'list_title' => esc_html__( 'Special Feature #2', 'dreamit-elementor-extension' ),
						],
					],
					'title_field' => '{{{ list_title }}}',
				]
			);

			$this->add_control(
				'button_text',
				[
					'label' => __( 'Text', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'dynamic' => [
						'active' => true,
					],
					'placeholder' => __( 'Click Here', 'dreamit-elementor-extension' ),
					'label_block' => true,
					'default' => __( 'Click Here', 'dreamit-elementor-extension' ),
				]
			);
			$this->add_control(
				'button_link',
				[
					'label' => __( 'Link', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::URL,
					'placeholder' => __( 'https://your-link.com', 'dreamit-elementor-extension' ),
				]
			);
			$this->add_control(
				'button_icon',
				[
					'label' => __( 'Icon', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::ICONS,
				]
			);
		$this->end_controls_section();

		// pakage two
			$this->start_controls_section(
			'package_section_two',
			[
				'label' => __( 'Package Item 2', 'dreamit-elementor-extension' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
			$this->add_control(
				'name_two',
				[
					'label' => __( 'Name', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'default' => __( 'Basic', 'dreamit-elementor-extension' ),
					'placeholder' => __( 'Enter Title', 'dreamit-elementor-extension' ),
				]
			);
			$this->add_control(
				'title_two',
				[
					'label' => esc_html__( 'Title', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'default' => esc_html__( 'Default title', 'dreamit-elementor-extension' ),
					'placeholder' => esc_html__( 'Type your title here', 'dreamit-elementor-extension' ),
					'label_block' => true,
				]
			);
			$this->add_control(
				'sub_title_two',
				[
					'label' => esc_html__( 'Sub Title', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'default' => esc_html__( 'Default title', 'dreamit-elementor-extension' ),
					'placeholder' => esc_html__( 'Type your title here', 'dreamit-elementor-extension' ),
					'label_block' => true,
				]
			);
			$this->add_control(
				'description_two',
				[
					'label' => esc_html__( 'Description', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::TEXTAREA,
					'rows' => 5,
					'default' => esc_html__( 'Default description', 'dreamit-elementor-extension' ),
					'placeholder' => esc_html__( 'Type your description here', 'dreamit-elementor-extension' ),
				]
			);
			$this->add_control(
				'currency_two',
				[
					'label' => __( 'Currency', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'default' => __( '$', 'dreamit-elementor-extension' ),
					'placeholder' => __( '$', 'dreamit-elementor-extension' ),
				]
			);
			$this->add_control(
				'price_two',
				[
					'label' => __( 'Price', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'default' => __( '99', 'dreamit-elementor-extension' ),
					'placeholder' => __( '99', 'dreamit-elementor-extension' ),
				]
			);
			$this->add_control(
				'month_two',
				[
					'label' => __( 'Month', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'default' => __( 'Month', 'dreamit-elementor-extension' ),
					'placeholder' => __( 'Month', 'dreamit-elementor-extension' ),
				]
			);
			// 	yearly
            
            $this->add_control(
				'currency_yearly_two',
				[
					'label' => __( 'Yearly Currency', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'default' => __( '$', 'dreamit-elementor-extension' ),
					'placeholder' => __( '$', 'dreamit-elementor-extension' ),
				]
			);
			$this->add_control(
				'price_yearly_two',
				[
					'label' => __( 'Yearly Price', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'default' => __( '99', 'dreamit-elementor-extension' ),
					'placeholder' => __( '99', 'dreamit-elementor-extension' ),
				]
			);
			$this->add_control(
				'month_yearly_two',
				[
					'label' => __( 'Yearly Month', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'default' => __( 'Month', 'dreamit-elementor-extension' ),
					'placeholder' => __( 'Month', 'dreamit-elementor-extension' ),
				]
			);
			$repeater = new \Elementor\Repeater();

			$repeater->add_control(
				'icons_type',
				[
				    'label' => esc_html__('Icon Type','dreamit-elementor-extension'),
				    'type' => \Elementor\Controls_Manager::CHOOSE,
				    'options' =>[
					  'img' =>[
						'title' =>esc_html__('Image','dreamit-elementor-extension'),
						'icon' =>'eicon-image',
					  ],
					  'icon' =>[
						'title' =>esc_html__('Icon','dreamit-elementor-extension'),
						'icon' =>'fa fa-info',
					  ]
				    ],
				    'default' => 'icon',
				]
			 );
             $repeater->add_control(
				'list_icon',
				[
					'label' => esc_html__( 'Icon', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::ICONS,
					'condition'=>[
						'icons_type'=> 'icon',
					],
					'label_block' => true,
				]
			);
			$repeater->add_control(
				'list_img',
				[
				    'label' => esc_html__('Image','dreamit-elementor-extension'),
				    'type'=> \Elementor\Controls_Manager::MEDIA,
				    'default' => [
					  'url' => \Elementor\Utils::get_placeholder_image_src(),
				    ],
				    'condition' => [
					  'icons_type' => 'img',
				    ]
				]
			);
			$repeater->add_control(
				'list_title_two', [
					'label' => esc_html__( 'Title', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'default' => esc_html__( 'List Title' , 'dreamit-elementor-extension' ),
					'label_block' => true,
				]
			);

			$this->add_control(
				'feature_list_two',
				[
					'label' => esc_html__( 'Feature List', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::REPEATER,
					'fields' => $repeater->get_controls(),
					'default' => [
						[
							'list_title' => esc_html__( 'Special Feature #1', 'dreamit-elementor-extension' ),
						],
						[
							'list_title' => esc_html__( 'Special Feature #2', 'dreamit-elementor-extension' ),
						],
					],
					'title_field' => '{{{ list_title }}}',
				]
			);

		$this->end_controls_section();
	// pakage three
			$this->start_controls_section(
			'package_section_three',
			[
				'label' => __( 'Package Item 3', 'dreamit-elementor-extension' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
			$this->add_control(
				'name_three',
				[
					'label' => __( 'Name', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'default' => __( 'Basic', 'dreamit-elementor-extension' ),
					'placeholder' => __( 'Enter Title', 'dreamit-elementor-extension' ),
				]
			);
			$this->add_control(
				'title_three',
				[
					'label' => esc_html__( 'Title', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'default' => esc_html__( 'Default title', 'dreamit-elementor-extension' ),
					'placeholder' => esc_html__( 'Type your title here', 'dreamit-elementor-extension' ),
					'label_block' => true,
				]
			);
			$this->add_control(
				'sub_title_three',
				[
					'label' => esc_html__( 'Sub Title', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'default' => esc_html__( 'Default title', 'dreamit-elementor-extension' ),
					'placeholder' => esc_html__( 'Type your title here', 'dreamit-elementor-extension' ),
					'label_block' => true,
				]
			);
			$this->add_control(
				'description_three',
				[
					'label' => esc_html__( 'Description', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::TEXTAREA,
					'rows' => 5,
					'default' => esc_html__( 'Default description', 'dreamit-elementor-extension' ),
					'placeholder' => esc_html__( 'Type your description here', 'dreamit-elementor-extension' ),
				]
			);
			$this->add_control(
				'currency_three',
				[
					'label' => __( 'Currency', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'default' => __( '$', 'dreamit-elementor-extension' ),
					'placeholder' => __( '$', 'dreamit-elementor-extension' ),
				]
			);
			$this->add_control(
				'price_three',
				[
					'label' => __( 'Price', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'default' => __( '99', 'dreamit-elementor-extension' ),
					'placeholder' => __( '99', 'dreamit-elementor-extension' ),
				]
			);
			$this->add_control(
				'month_three',
				[
					'label' => __( 'Month', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'default' => __( 'Month', 'dreamit-elementor-extension' ),
					'placeholder' => __( 'Month', 'dreamit-elementor-extension' ),
				]
			);
			// 	yearly
            
            $this->add_control(
				'currency_yearly_three',
				[
					'label' => __( 'Yearly Currency', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'default' => __( '$', 'dreamit-elementor-extension' ),
					'placeholder' => __( '$', 'dreamit-elementor-extension' ),
				]
			);
			$this->add_control(
				'price_yearly_three',
				[
					'label' => __( 'Yearly Price', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'default' => __( '99', 'dreamit-elementor-extension' ),
					'placeholder' => __( '99', 'dreamit-elementor-extension' ),
				]
			);
			$this->add_control(
				'month_yearly_three',
				[
					'label' => __( 'Yearly Month', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'default' => __( 'Month', 'dreamit-elementor-extension' ),
					'placeholder' => __( 'Month', 'dreamit-elementor-extension' ),
				]
			);
			$repeater = new \Elementor\Repeater();

			$repeater->add_control(
				'icons_type',
				[
				    'label' => esc_html__('Icon Type','dreamit-elementor-extension'),
				    'type' => \Elementor\Controls_Manager::CHOOSE,
				    'options' =>[
					  'img' =>[
						'title' =>esc_html__('Image','dreamit-elementor-extension'),
						'icon' =>'eicon-image',
					  ],
					  'icon' =>[
						'title' =>esc_html__('Icon','dreamit-elementor-extension'),
						'icon' =>'fa fa-info',
					  ]
				    ],
				    'default' => 'icon',
				]
			 );
             $repeater->add_control(
				'list_icon',
				[
					'label' => esc_html__( 'Icon', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::ICONS,
					'condition'=>[
						'icons_type'=> 'icon',
					],
					'label_block' => true,
				]
			);
			$repeater->add_control(
				'list_img',
				[
				    'label' => esc_html__('Image','dreamit-elementor-extension'),
				    'type'=> \Elementor\Controls_Manager::MEDIA,
				    'default' => [
					  'url' => \Elementor\Utils::get_placeholder_image_src(),
				    ],
				    'condition' => [
					  'icons_type' => 'img',
				    ]
				]
			);
			$repeater->add_control(
				'list_title_three', [
					'label' => esc_html__( 'Title', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'default' => esc_html__( 'List Title' , 'dreamit-elementor-extension' ),
					'label_block' => true,
				]
			);

			$this->add_control(
				'feature_list_three',
				[
					'label' => esc_html__( 'Feature List', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::REPEATER,
					'fields' => $repeater->get_controls(),
					'default' => [
						[
							'list_title' => esc_html__( 'Special Feature #1', 'dreamit-elementor-extension' ),
						],
						[
							'list_title' => esc_html__( 'Special Feature #2', 'dreamit-elementor-extension' ),
						],
					],
					'title_field' => '{{{ list_title }}}',
				]
			);

		$this->end_controls_section();

/**
 * Style Tab
 */

		$this->start_controls_section(
			'general_section',
			[
				'label' => __( 'General', 'dreamit-elementor-extension' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
			$this->add_control(
				'select_style',
				[
					'label' => __( 'Select Style', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::SELECT,
					'options' => [
						'one' => __( 'One', 'dreamit-elementor-extension' ),
						'two' => __( 'Two', 'dreamit-elementor-extension' ),
					],
					'default' => 'one',
				]
			);

		$this->end_controls_section();

		$this->start_controls_section(
			'menu_style',
			[
				'label' => __( 'Current Menu', 'dreamit-elementor-extension' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

			$this->add_control(
				'menu_color',
				[
					'label' => esc_html__( 'Color', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .tab .pricing-toggle span' => 'color: {{VALUE}}',
					],
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name' => 'current_menu_typography',
					'label' => __( 'Typography', 'dreamit-elementor-extension' ),
					'selector' => '{{WRAPPER}} .tab .pricing-toggle span',
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Background::get_type(),
				[
					'name' => 'current_menu_background',
					'label' => esc_html__( 'Background', 'dreamit-elementor-extension' ),
					'types' => [ 'classic', 'gradient' ],
					'selector' => '{{WRAPPER}}  .tab .pricing-toggle span',
				]
			);
		$this->end_controls_section();
		$this->start_controls_section(
			'top_title_style',
			[
				'label' => __( 'Top Title', 'dreamit-elementor-extension' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
			$this->add_control(
				'top_title_color',
				[
					'label' => esc_html__( 'Color', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .pricing_single_items .price_item_inner_center h5' => 'color: {{VALUE}}',
					],
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name' => 'top_title_typography',
					'label' => __( 'Typography', 'dreamit-elementor-extension' ),
					'selector' => '{{WRAPPER}} .pricing_single_items .price_item_inner_center h5',
				]
			);
		$this->end_controls_section();

		$this->start_controls_section(
			'name_style',
			[
				'label' => __( 'Package Name', 'dreamit-elementor-extension' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

			$this->add_control(
				'name_color',
				[
					'label' => esc_html__( 'Color', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .pricing_single_items .price_item_inner_center h3' => 'color: {{VALUE}}',
					],
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name' => 'name_typography',
					'label' => __( 'Typography', 'dreamit-elementor-extension' ),
					'selector' => '{{WRAPPER}} .pricing_single_items .price_item_inner_center h3',
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Background::get_type(),
				[
					'name' => 'name_background',
					'label' => esc_html__( 'Background', 'dreamit-elementor-extension' ),
					'types' => [ 'classic', 'gradient' ],
					'selector' => '{{WRAPPER}} .pricing_single_items .price_item_inner_center h3',
				]
			);
			$this->add_responsive_control(
				'name_padding',
				[
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'label' => esc_html__( 'Padding', 'dreamit-elementor-extension' ),
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .pricing_single_items .price_item_inner_center h3' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

		$this->end_controls_section();
		$this->start_controls_section(
			'sub_title_style',
			[
				'label' => __( 'Sub Title', 'dreamit-elementor-extension' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
			$this->add_control(
				'sub_title_color',
				[
					'label' => __( 'Color', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .pricing_single_items .sub-title h4 ' => 'color: {{VALUE}}',
					],
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name' => 'sub_title_typography',
					'label' => __( 'Typography', 'dreamit-elementor-extension' ),
					'selector' => '{{WRAPPER}} .pricing_single_items .sub-title h4',
				]
			);
			$this->add_responsive_control(
				'sub_title_margin',
				[
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'label' => esc_html__( 'Margin', 'dreamit-elementor-extension' ),
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .pricing_single_items .sub-title h4' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);
		$this->end_controls_section();
		$this->start_controls_section(
			'description_style',
			[
				'label' => __( 'Title & Description', 'dreamit-elementor-extension' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
			$this->add_control(
				'description_heading',
				[
					'label' => esc_html__( 'Description', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::HEADING,
					'separator' => 'before',
				]
			);
			$this->add_control(
				'description_color',
				[
					'label' => __( 'Color', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .pricing_single_items .description ' => 'color: {{VALUE}}',
					],
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name' => 'description_typography',
					'label' => __( 'Typography', 'dreamit-elementor-extension' ),
					'selector' => '{{WRAPPER}} .pricing_single_items .description',
				]
			);
			$this->add_responsive_control(
				'description_margin',
				[
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'label' => esc_html__( 'Margin', 'dreamit-elementor-extension' ),
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .pricing_single_items .description' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

		$this->end_controls_section();
		$this->start_controls_section(
			'currency_style',
			[
				'label' => __( 'Currency', 'dreamit-elementor-extension' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

			$this->add_control(
				'currency_color',
				[
					'label' => __( 'Currency Color', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .pricing_single_items span.curencyp' => 'color: {{VALUE}}',
					],
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name' => 'currency_typography',
					'label' => __( 'Currency Typography', 'dreamit-elementor-extension' ),
					'selector' => '{{WRAPPER}} .pricing_single_items span.curencyp',
				]
			);

		$this->end_controls_section();

		$this->start_controls_section(
			'price_style',
			[
				'label' => __( 'Price', 'dreamit-elementor-extension' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

			$this->add_control(
				'price_color',
				[
					'label' => __( 'Price Color', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .pricing_single_items .tk' => 'color: {{VALUE}}',
					],
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name' => 'price_typography',
					'label' => __( 'Price Typography', 'dreamit-elementor-extension' ),
					'selector' => '{{WRAPPER}} .pricing_single_items .tk',
				]
			);

		$this->end_controls_section();
		$this->start_controls_section(
			'month_style',
			[
				'label' => __( 'Month', 'dreamit-elementor-extension' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
			$this->add_control(
				'month_color',
				[
					'label' => __( 'Month Color', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .pricing_single_items span.bootmp' => 'color: {{VALUE}}',
					],
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name' => 'month_typography',
					'label' => __( 'Month Typography', 'dreamit-elementor-extension' ),
					'selector' => '{{WRAPPER}} .pricing_single_items span.bootmp',
				]
			);

		$this->end_controls_section();

		$this->start_controls_section(
			'features_style',
			[
				'label' => __( 'Features', 'dreamit-elementor-extension' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
			$this->add_control(
				'feature_color',
				[
					'label' => __( 'Color', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .pricing_single_items .pricing-feature.style_1 ul li' => 'color: {{VALUE}}',
					],
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name' => 'feature_typography',
					'label' => __( 'Typography', 'dreamit-elementor-extension' ),
					'selector' => '{{WRAPPER}} .pricing_single_items .pricing-feature.style_1 ul li',
				]
			);
			$this->add_responsive_control(
				'feature_margin',
				[
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'label' => esc_html__( 'Margin', 'dreamit-elementor-extension' ),
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .pricing_single_items .pricing-feature.style_1 ul li' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

		$this->end_controls_section();

		$this->start_controls_section(
			'features_icon_style',
			[
				'label' => __( 'Features Icon', 'dreamit-elementor-extension' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
			$this->add_control(
				'features_icon_color',
				[
					'label' => __( 'Color', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .pricing_single_items .pricing-feature.style_1 ul li i' => 'color: {{VALUE}}',
					],
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name' => 'features_icon_typography',
					'label' => __( 'Typography', 'dreamit-elementor-extension' ),
					'selector' => '{{WRAPPER}} .pricing_single_items .pricing-feature.style_1 ul li i',
				]
			);
			$this->add_responsive_control(
				'features_icon_margin',
				[
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'label' => esc_html__( 'Margin', 'dreamit-elementor-extension' ),
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .pricing_single_items .pricing-feature.style_1 ul li i' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

		$this->end_controls_section();

		$this->start_controls_section(
			'button_style',
			[
				'label' => esc_html__( 'Button', 'dreamit-elementor-extension' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name' => 'button_typography',
					'selector' => '{{WRAPPER}} .pricing_single_items .pricing-btn a',
				]
			);

			$this->start_controls_tabs(
				'style_tabs'
			);

			$this->start_controls_tab(
				'style_normal_tab',
				[
					'label' => esc_html__( 'Normal', 'dreamit-elementor-extension' ),
				]
			);

			$this->add_control(
				'text_color',
				[
					'label' => esc_html__( 'Text Color', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .pricing_single_items .pricing-btn a' => 'color: {{VALUE}}',
					],
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Background::get_type(),
				[
					'name' => 'background',
					'label' => esc_html__( 'Background', 'dreamit-elementor-extension' ),
					'types' => [ 'classic', 'gradient' ],
					'selector' => '{{WRAPPER}} .pricing_single_items .pricing-btn a',
				]
			);

			$this->end_controls_tab();

			$this->start_controls_tab(
				'style_hover_tab',
				[
					'label' => esc_html__( 'Hover', 'dreamit-elementor-extension' ),
				]
			);

			$this->add_control(
				'text_hover_color',
				[
					'label' => esc_html__( 'Text Color', 'dreamit-elementor-extension' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .pricing_single_items .pricing-btn a:hover' => 'color: {{VALUE}}',
					],
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Background::get_type(),
				[
					'name' => 'hover_background',
					'label' => esc_html__( 'Background', 'dreamit-elementor-extension' ),
					'types' => [ 'classic', 'gradient' ],
					'selector' => '{{WRAPPER}} .pricing_single_items .pricing-btn a:hover',
				]
			);

			$this->end_controls_tab();

			$this->end_controls_tabs();

			$this->add_group_control(
				\Elementor\Group_Control_Border::get_type(),
				[
					'name' => 'button_border',
					'label' => esc_html__( 'Border', 'dreamit-elementor-extension' ),
					'selector' => '{{WRAPPER}} .pricing_single_items .pricing-btn a',
					'separator' => 'before',
				]
			);
			$this->add_responsive_control(
				'button_border_radius',
				[
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'label' => esc_html__( 'Border Radius', 'dreamit-elementor-extension' ),
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .pricing_single_items .pricing-btn a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Box_Shadow::get_type(),
				[
					'name' => 'box_shadow',
					'label' => esc_html__( 'Box Shadow', 'dreamit-elementor-extension' ),
					'selector' => '{{WRAPPER}} .pricing_single_items .pricing-btn a',
				]
			);
			$this->add_responsive_control(
				'button_padding',
				[
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'label' => esc_html__( 'Padding', 'dreamit-elementor-extension' ),
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .pricing_single_items .pricing-btn a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

		$this->end_controls_section();

	}

	protected function render() {

		$settings = $this->get_settings_for_display();

		?>

		<?php if($settings['select_style']=='one'){ ?>
		<div class="pricing_area style_one">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 pl-0">
					<div class="tab">
						<div class="pricing-toggle">
						    <span style="margin: 0.8em;"><?php echo $settings['menu_current'];?></span>
						<label class="switch">
							<input type="checkbox" id="pricing-toggle-checkbox">
							<span class="slider"></span>
						</label>
						    <span style="margin: 0.8em;"><?php echo $settings['menu_current1'];?></span>
					    </div>
						 <!-- / tabs -->
						<div class="tab_content">
							<div class="tabs_item">
								<div class="row">
									<div class="col-lg-4 col-md-6">
										<div class="pricing_single_items style_one wow fadeInLeftBig" id="price-monthly">
											<div class="price_item_inner_center">
											    <div class="price_item">
											        <div class="price_item_inner">
											        	<h5 class="top-title"><?php echo $settings['site_title'];?></h5>
        											    <h3 class="pricing-plan"><?php echo $settings['title']; ?></h3>
        											    <h4 class="sub-title"><?php echo $settings['sub_title'];?></h4>
        											    <h2 class="price price-monthly" id="price-monthly" style="display: block;">
            												<?php if( !empty($settings['currency']) ){ ?>
            												    <span class="curencyp"><?php echo $settings['currency']; ?></span>
            												<?php } ?>
            												<?php if( !empty($settings['price']) ){ ?>
            												    <span class="tk"><?php echo $settings['price']; ?></span>
            												<?php } ?>
            												<?php if( !empty($settings['month']) ){ ?>
                												<span class="monthp">
                													<span class="month_inner">
                														<span class="bootmp"><?php echo $settings['month']; ?></span>
                													</span>
                												</span>
            												<?php } ?>
        												</h2>
        												<h2 class="price price-yearly" id="price-yearly" style="display: none;">
        												    <?php if( !empty($settings['currency_yearly']) ){ ?>
            												    <span class="curencyp"><?php echo $settings['currency_yearly']; ?></span>
            												<?php } ?>
            												<?php if( !empty($settings['price_yearly']) ){ ?>
            												    <span class="tk"><?php echo $settings['price_yearly']; ?></span>
            												<?php } ?>
            												<?php if( !empty($settings['month_yearly']) ){ ?>
                												<span class="monthp">
                													<span class="month_inner">
                														<span class="bootmp"><?php echo $settings['month_yearly']; ?></span>
                													</span>
                												</span>
            												<?php } ?>
        												</h2>
    												</div>
												</div>
												<?php if( !empty($settings['description']) ){ ?>
													<p class="description"><?php echo $settings['description'];?></p>
												<?php } ?>
											</div>	
						                	<div class="pricing-body style_one">
												<div class="pricing-feature style_1">
													<ul class="features">											
														<?php foreach (  $settings['feature_list'] as $item ) { ?>
															<li>
															    <?php if($item['icons_type'] == 'icon' ){ ?>
                                            						<?php \Elementor\Icons_Manager::render_icon( $item['list_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                                            					<?php }elseif($item['icons_type'] == 'img'){ ?>
                                            						<img src="<?php echo $item['list_img']['url']; ?>" alt="">
                                            					<?php } ?>
																<?php echo $item['list_title']; ?>
															</li>
														<?php } ?>													
													</ul>
												</div>
											</div>
											<div class="pricing-btn">
												<a class="pricing-button" href="<?php echo esc_url($settings['button_link']['url']); ?>" class="singinp"> <?php \Elementor\Icons_Manager::render_icon( $settings['button_icon'], [ 'aria-hidden' => 'true' ] ); ?> <?php echo $settings['button_text']; ?></a>
											</div>
										</div>
									</div>
									<div class="col-lg-4 col-md-6">
										<div class="pricing_single_items style_one wow fadeUpBottomBig" id="price-monthly">
											<div class="price_item_inner_center">
											    <div class="price_item">
    											    <div class="price_item_inner">
    											    	<h5 class="top-title"><?php echo $settings['site_title'];?></h5>
        											    <h3 class="pricing-plan"><?php echo $settings['title_two']; ?>
        											    <h4 class="sub-title"><?php echo $settings['sub_title'];?></h4>
        											    </h3>
            											  <h2 class="price price-monthly" id="price-monthly" style="display: block;">
            												<?php if( !empty($settings['currency_two']) ){ ?>
            												<span class="curencyp"><?php echo $settings['currency_two']; ?></span>
            												<?php } ?>
            												<?php if( !empty($settings['price_two']) ){ ?>
            												<span class="tk"><?php echo $settings['price_two']; ?></span>
            												<?php } ?>
            												<?php if( !empty($settings['month_two']) ){ ?>
            												<span class="monthp">
            													<span class="month_inner">
            														<span class="bootmp"><?php echo $settings['month_two']; ?></span>
            													</span>
            												</span>
            												<?php } ?>
        												</h2>
        												<h2 class="price price-yearly" id="price-yearly" style="display: none;">
        												    <?php if( !empty($settings['currency_yearly_two']) ){ ?>
            												    <span class="curencyp"><?php echo $settings['currency_yearly_two']; ?></span>
            												<?php } ?>
            												<?php if( !empty($settings['price_yearly_two']) ){ ?>
            												    <span class="tk"><?php echo $settings['price_yearly_two']; ?></span>
            												<?php } ?>
            												<?php if( !empty($settings['month_yearly_two']) ){ ?>
                												<span class="monthp">
                													<span class="month_inner">
                														<span class="bootmp"><?php echo $settings['month_yearly_two']; ?></span>
                													</span>
                												</span>
            												<?php } ?>
        												</h2>
    												</div>
												</div>
												<?php if( !empty($settings['description_two']) ){ ?>
													<p class="description"><?php echo $settings['description_two'];?></p>
												<?php } ?>
											</div>
											<div class="pricing-body style_one">
												<div class="pricing-feature style_1">
													<ul class="features">										
														<?php foreach (  $settings['feature_list_two'] as $item ) { ?>
															<li>
															    <?php if($item['icons_type'] == 'icon' ){ ?>
                                            						<?php \Elementor\Icons_Manager::render_icon( $item['list_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                                            					<?php }elseif($item['icons_type'] == 'img'){ ?>
                                            						<img src="<?php echo $item['list_img']['url']; ?>" alt="">
                                            					<?php } ?>
																<?php echo $item['list_title_two']; ?>
															</li>
														<?php } ?>												
													</ul>
												</div>
											</div>
											<div class="pricing-btn">
												<a class="pricing-button" href="<?php echo esc_url($settings['button_link']['url']); ?>" class="singinp"> <?php \Elementor\Icons_Manager::render_icon( $settings['button_icon'], [ 'aria-hidden' => 'true' ] ); ?> <?php echo $settings['button_text']; ?></a>
											</div>
										</div>
									</div>
									<div class="col-lg-4 col-md-6">
										<div class="pricing_single_items style_one wow fadeInRightBig" id="price-monthly">
											<div class="price_item_inner_center">
											    <div class="price_item">
    											    <div class="price_item_inner">
    											    	<h5 class="top-title"><?php echo $settings['site_title'];?></h5>
        											    <h3 class="pricing-plan"><?php echo $settings['title_three']; ?></h3>
        											    <h4 class="sub-title"><?php echo $settings['sub_title'];?></h4>
            								            <h2 class="price price-monthly" id="price-monthly" style="display: block;">
                											<?php if( !empty($settings['currency_three']) ){ ?>
                												<span class="curencyp"><?php echo $settings['currency_two']; ?></span>
                											<?php } ?>
                											<?php if( !empty($settings['price_three']) ){ ?>
                												<span class="tk"><?php echo $settings['price_three']; ?></span>
                											<?php } ?>
                											<?php if( !empty($settings['month_three']) ){ ?>
                												<span class="monthp">
                													<span class="month_inner">
                														<span class="bootmp"><?php echo $settings['month_three']; ?></span>
                													</span>
                												</span>
        												    <?php } ?>
        												</h2>
        												<h2 class="price price-yearly" id="price-yearly" style="display: none;">
        												    <?php if( !empty($settings['currency_yearly_three']) ){ ?>
            												    <span class="curencyp"><?php echo $settings['currency_yearly_three']; ?></span>
            												<?php } ?>
            												<?php if( !empty($settings['price_yearly_three']) ){ ?>
            												    <span class="tk"><?php echo $settings['price_yearly_three']; ?></span>
            												<?php } ?>
            												<?php if( !empty($settings['month_yearly_three']) ){ ?>
                												<span class="monthp">
                													<span class="month_inner">
                														<span class="bootmp"><?php echo $settings['month_yearly_three']; ?></span>
                													</span>
                												</span>
            												<?php } ?>
        												</h2>
        											</div>
												</div>
												<?php if( !empty($settings['description_three']) ){ ?>
													<p class="description"><?php echo $settings['description_three'];?></p>
												<?php } ?>
											</div>
											<div class="pricing-body style_one">
												<div class="pricing-feature style_1">
													<ul class="features">										
														<?php foreach (  $settings['feature_list_three'] as $item ) { ?>
															<li>
															    <?php if($item['icons_type'] == 'icon' ){ ?>
                                            						<?php \Elementor\Icons_Manager::render_icon( $item['list_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                                            					<?php }elseif($item['icons_type'] == 'img'){ ?>
                                            						<img src="<?php echo $item['list_img']['url']; ?>" alt="">
                                            					<?php } ?>
																<?php echo $item['list_title_three']; ?>
															</li>
														<?php } ?>														
													</ul>
												</div>
											</div>
											<div class="pricing-btn">
												<a class="pricing-button" href="<?php echo esc_url($settings['button_link']['url']); ?>" class="singinp"> <?php \Elementor\Icons_Manager::render_icon( $settings['button_icon'], [ 'aria-hidden' => 'true' ] ); ?> <?php echo $settings['button_text']; ?></a>
											</div>
										</div>
									</div>
								</div>
							</div> 					
						</div> 
					</div> 				
				</div>							
			</div>
		</div>
	</div>
	   <script>
		const toggleCheckbox = document.getElementById('pricing-toggle-checkbox');		
		const priceMonthly = document.querySelectorAll('.price-monthly');
		const priceYearly = document.querySelectorAll('.price-yearly');
		toggleCheckbox.addEventListener('change', function() {
			if (this.checked) {
				// Monthly
				priceMonthly[0].style.display = "none";
				priceMonthly[1].style.display = "none";
				priceMonthly[2].style.display = "none";
				// yerarly
				priceYearly[0].style.display= "block"
				priceYearly[1].style.display= "block"
				priceYearly[2].style.display= "block"
			} else {
				// Monthly
				priceMonthly[0].style.display = "block";
				priceMonthly[1].style.display = "block";
				priceMonthly[2].style.display = "block";
				// Yearly
				priceYearly[0].style.display= "none"
				priceYearly[1].style.display= "none"
				priceYearly[2].style.display= "none"
			}
		});
	</script>

		<?php }if($settings['select_style']=='two'){ ?>
		<div class="pricing_area style_one style_two">
		<div class="container">
			<div class="row">
				<div class="col-lg-12 pl-0">
					<div class="tab">
						<div class="pricing-toggle">
						    <span style="margin: 0.8em;"><?php echo $settings['menu_current'];?></span>
						<label class="switch">
							<input type="checkbox" id="pricing-toggle-checkbox">
							<span class="slider"></span>
						</label>
						    <span style="margin: 0.8em;"><?php echo $settings['menu_current1'];?></span>
					    </div>
						 <!-- / tabs -->
						<div class="tab_content">
							<div class="tabs_item">
								<div class="row">
									<div class="col-lg-4 col-md-6">
										<div class="pricing_single_items style_one wow fadeInLeftBig" id="price-monthly">
											<div class="price_item_inner_center">
											    <div class="price_item">
											        <div class="price_item_inner">
											        	<h5 class="top-title"><?php echo $settings['site_title'];?></h5>
        											    <h3 class="pricing-plan"><?php echo $settings['title']; ?></h3>
        											    <h4 class="sub-title"><?php echo $settings['sub_title'];?></h4>
        											    <h2 class="price price-monthly" id="price-monthly" style="display: block;">
            												<?php if( !empty($settings['currency']) ){ ?>
            												    <span class="curencyp"><?php echo $settings['currency']; ?></span>
            												<?php } ?>
            												<?php if( !empty($settings['price']) ){ ?>
            												    <span class="tk"><?php echo $settings['price']; ?></span>
            												<?php } ?>
            												<?php if( !empty($settings['month']) ){ ?>
                												<span class="monthp">
                													<span class="month_inner">
                														<span class="bootmp"><?php echo $settings['month']; ?></span>
                													</span>
                												</span>
            												<?php } ?>
        												</h2>
        												<h2 class="price price-yearly" id="price-yearly" style="display: none;">
        												    <?php if( !empty($settings['currency_yearly']) ){ ?>
            												    <span class="curencyp"><?php echo $settings['currency_yearly']; ?></span>
            												<?php } ?>
            												<?php if( !empty($settings['price_yearly']) ){ ?>
            												    <span class="tk"><?php echo $settings['price_yearly']; ?></span>
            												<?php } ?>
            												<?php if( !empty($settings['month_yearly']) ){ ?>
                												<span class="monthp">
                													<span class="month_inner">
                														<span class="bootmp"><?php echo $settings['month_yearly']; ?></span>
                													</span>
                												</span>
            												<?php } ?>
        												</h2>
    												</div>
												</div>
												<?php if( !empty($settings['description']) ){ ?>
													<p class="description"><?php echo $settings['description'];?></p>
												<?php } ?>
												<div class="pricing-btn">
													<a class="pricing-button" href="<?php echo esc_url($settings['button_link']['url']); ?>" class="singinp"> <?php echo $settings['button_text']; ?><?php \Elementor\Icons_Manager::render_icon( $settings['button_icon'], [ 'aria-hidden' => 'true' ] ); ?></a>
												</div>
											</div>	
						                	<div class="pricing-body style_one">
												<div class="pricing-feature style_1">
													<ul class="features">											
														<?php foreach (  $settings['feature_list'] as $item ) { ?>
															<li>
															    <?php if($item['icons_type'] == 'icon' ){ ?>
                                            						<?php \Elementor\Icons_Manager::render_icon( $item['list_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                                            					<?php }elseif($item['icons_type'] == 'img'){ ?>
                                            						<img src="<?php echo $item['list_img']['url']; ?>" alt="">
                                            					<?php } ?>
																<?php echo $item['list_title']; ?>
															</li>
														<?php } ?>													
													</ul>
												</div>
											</div>
										</div>
									</div>
									<div class="col-lg-4 col-md-6">
										<div class="pricing_single_items style_one wow fadeUpBottomBig" id="price-monthly">
											<div class="price_item_inner_center">
											    <div class="price_item">
    											    <div class="price_item_inner">
    											    	<h5 class="top-title"><?php echo $settings['site_title'];?></h5>
        											    <h3 class="pricing-plan"><?php echo $settings['title_two']; ?>
        											    <h4 class="sub-title"><?php echo $settings['sub_title'];?></h4>
        											    </h3>
            											  <h2 class="price price-monthly" id="price-monthly" style="display: block;">
            												<?php if( !empty($settings['currency_two']) ){ ?>
            												<span class="curencyp"><?php echo $settings['currency_two']; ?></span>
            												<?php } ?>
            												<?php if( !empty($settings['price_two']) ){ ?>
            												<span class="tk"><?php echo $settings['price_two']; ?></span>
            												<?php } ?>
            												<?php if( !empty($settings['month_two']) ){ ?>
            												<span class="monthp">
            													<span class="month_inner">
            														<span class="bootmp"><?php echo $settings['month_two']; ?></span>
            													</span>
            												</span>
            												<?php } ?>
        												</h2>
        												<h2 class="price price-yearly" id="price-yearly" style="display: none;">
        												    <?php if( !empty($settings['currency_yearly_two']) ){ ?>
            												    <span class="curencyp"><?php echo $settings['currency_yearly_two']; ?></span>
            												<?php } ?>
            												<?php if( !empty($settings['price_yearly_two']) ){ ?>
            												    <span class="tk"><?php echo $settings['price_yearly_two']; ?></span>
            												<?php } ?>
            												<?php if( !empty($settings['month_yearly_two']) ){ ?>
                												<span class="monthp">
                													<span class="month_inner">
                														<span class="bootmp"><?php echo $settings['month_yearly_two']; ?></span>
                													</span>
                												</span>
            												<?php } ?>
        												</h2>
    												</div>
												</div>
												<?php if( !empty($settings['description_two']) ){ ?>
													<p class="description"><?php echo $settings['description_two'];?></p>
												<?php } ?>
												<div class="pricing-btn">
													<a class="pricing-button" href="<?php echo esc_url($settings['button_link']['url']); ?>" class="singinp">  <?php echo $settings['button_text']; ?> <?php \Elementor\Icons_Manager::render_icon( $settings['button_icon'], [ 'aria-hidden' => 'true' ] ); ?></a>
												</div>
											</div>
											<div class="pricing-body style_one">
												<div class="pricing-feature style_1">
													<ul class="features">										
														<?php foreach (  $settings['feature_list_two'] as $item ) { ?>
															<li>
															    <?php if($item['icons_type'] == 'icon' ){ ?>
                                            						<?php \Elementor\Icons_Manager::render_icon( $item['list_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                                            					<?php }elseif($item['icons_type'] == 'img'){ ?>
                                            						<img src="<?php echo $item['list_img']['url']; ?>" alt="">
                                            					<?php } ?>
																<?php echo $item['list_title_two']; ?>
															</li>
														<?php } ?>												
													</ul>
												</div>
											</div>
										</div>
									</div>
									<div class="col-lg-4 col-md-6">
										<div class="pricing_single_items style_one wow fadeInRightBig" id="price-monthly">
											<div class="price_item_inner_center">
											    <div class="price_item">
    											    <div class="price_item_inner">
    											    	<h5 class="top-title"><?php echo $settings['site_title'];?></h5>
        											    <h3 class="pricing-plan"><?php echo $settings['title_three']; ?></h3>
        											    <h4 class="sub-title"><?php echo $settings['sub_title'];?></h4>
            								            <h2 class="price price-monthly" id="price-monthly" style="display: block;">
                											<?php if( !empty($settings['currency_three']) ){ ?>
                												<span class="curencyp"><?php echo $settings['currency_two']; ?></span>
                											<?php } ?>
                											<?php if( !empty($settings['price_three']) ){ ?>
                												<span class="tk"><?php echo $settings['price_three']; ?></span>
                											<?php } ?>
                											<?php if( !empty($settings['month_three']) ){ ?>
                												<span class="monthp">
                													<span class="month_inner">
                														<span class="bootmp"><?php echo $settings['month_three']; ?></span>
                													</span>
                												</span>
        												    <?php } ?>
        												</h2>
        												<h2 class="price price-yearly" id="price-yearly" style="display: none;">
        												    <?php if( !empty($settings['currency_yearly_three']) ){ ?>
            												    <span class="curencyp"><?php echo $settings['currency_yearly_three']; ?></span>
            												<?php } ?>
            												<?php if( !empty($settings['price_yearly_three']) ){ ?>
            												    <span class="tk"><?php echo $settings['price_yearly_three']; ?></span>
            												<?php } ?>
            												<?php if( !empty($settings['month_yearly_three']) ){ ?>
                												<span class="monthp">
                													<span class="month_inner">
                														<span class="bootmp"><?php echo $settings['month_yearly_three']; ?></span>
                													</span>
                												</span>
            												<?php } ?>
        												</h2>
        											</div>
												</div>
												<?php if( !empty($settings['description_three']) ){ ?>
													<p class="description"><?php echo $settings['description_three'];?></p>
												<?php } ?>
												<div class="pricing-btn">
													<a class="pricing-button" href="<?php echo esc_url($settings['button_link']['url']); ?>" class="singinp">  <?php echo $settings['button_text']; ?> <?php \Elementor\Icons_Manager::render_icon( $settings['button_icon'], [ 'aria-hidden' => 'true' ] ); ?></a>
												</div>
											</div>
											<div class="pricing-body style_one">
												<div class="pricing-feature style_1">
													<ul class="features">										
														<?php foreach (  $settings['feature_list_three'] as $item ) { ?>
															<li>
															    <?php if($item['icons_type'] == 'icon' ){ ?>
                                            						<?php \Elementor\Icons_Manager::render_icon( $item['list_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                                            					<?php }elseif($item['icons_type'] == 'img'){ ?>
                                            						<img src="<?php echo $item['list_img']['url']; ?>" alt="">
                                            					<?php } ?>
																<?php echo $item['list_title_three']; ?>
															</li>
														<?php } ?>														
													</ul>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div> 					
						</div> 
					</div> 				
				</div>							
			</div>
		</div>
	</div>
	   <script>
		const toggleCheckbox = document.getElementById('pricing-toggle-checkbox');		
		const priceMonthly = document.querySelectorAll('.price-monthly');
		const priceYearly = document.querySelectorAll('.price-yearly');
		toggleCheckbox.addEventListener('change', function() {
			if (this.checked) {
				// Monthly
				priceMonthly[0].style.display = "none";
				priceMonthly[1].style.display = "none";
				priceMonthly[2].style.display = "none";
				// yerarly
				priceYearly[0].style.display= "block"
				priceYearly[1].style.display= "block"
				priceYearly[2].style.display= "block"
			} else {
				// Monthly
				priceMonthly[0].style.display = "block";
				priceMonthly[1].style.display = "block";
				priceMonthly[2].style.display = "block";
				// Yearly
				priceYearly[0].style.display= "none"
				priceYearly[1].style.display= "none"
				priceYearly[2].style.display= "none"
			}
		});
	</script>

		<?php }
	}
}